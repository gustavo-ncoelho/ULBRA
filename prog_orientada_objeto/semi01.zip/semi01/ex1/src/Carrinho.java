import java.util.ArrayList;
import java.util.List;
public class Carrinho {
    private final List<Produto> listaCarrinho;
    private double valorTotal;
    public Carrinho(){
        listaCarrinho = new ArrayList<>();
        valorTotal = 0;
    }
    public void adicionarAoCarrinho(Produto produto){
        listaCarrinho.add(produto);
        System.out.println(produto.getNomeProduto() + " adicionado ao carrinho");
        valorTotal += produto.getValorProduto();
    }

//    private void somaTotal(){
//        for (Produto produto : listaCarrinho){
//            valorTotal += produto.getValorProduto();
//        }
//    }

    public void mostrarValorTotal(){
        System.out.println("O valor total é de: R$" + valorTotal);
    }

    public List<Produto> getListaCarrinho() {
        return listaCarrinho;
    }

    public double getValorTotal() {
        return valorTotal;
    }
}
